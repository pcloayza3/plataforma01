@echo off
title ClinikLocal - Gestion Clinica y Odontologica
echo Iniciando ClinikLocal en modo autonomo...
set PORT=4042

start /B python -m http.server %PORT% >nul 2>&1

timeout /t 1 /nobreak >nul

if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app="http://localhost:%PORT%/index.html"
) else if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --app="http://localhost:%PORT%/index.html"
) else if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app="http://localhost:%PORT%/index.html"
) else (
    start http://localhost:%PORT%/index.html
)
exit
