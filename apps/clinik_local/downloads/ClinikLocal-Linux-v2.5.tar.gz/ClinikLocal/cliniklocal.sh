#!/usr/bin/env bash
DIR="$(cd "$(dirname "$0")" && pwd)"
PORT=4042

python3 -m http.server $PORT --directory "$DIR" > /dev/null 2>&1 &
SERVER_PID=$!
sleep 0.5

if which google-chrome > /dev/null; then
    google-chrome --app="http://localhost:$PORT/index.html"
elif which chromium > /dev/null; then
    chromium --app="http://localhost:$PORT/index.html"
elif which xdg-open > /dev/null; then
    xdg-open "http://localhost:$PORT/index.html"
fi

wait $SERVER_PID
